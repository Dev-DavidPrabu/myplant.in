const Products = {
  products: [
    {
      id: '1',
      name: 'MacBook',
      price: 1400,
      description: "Lorem ipsum dolor sit, amet consectetur adipisicing elit.",
      image: 'https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/indoor-plants-1634736990.jpg?crop=1.00xw:1.00xh;0,0&resize=1200:*',
    },
    {
      id: '2',
      name: 'Sansevieria',
      price: 2400,
      description: "Lorem ipsum dolor sit, amet consectetur adipisicing elit.",

      image: 'https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/close-up-view-of-green-plants-in-flowerpots-on-royalty-free-image-952363770-1534872458.jpg?crop=1xw:0.7499xh;center,top&resize=1200:*',
    },
    {
      id: '3',
      name: 'W Shoes',
      price: 1000,
      description: "Lorem ipsum dolor sit, amet consectetur adipisicing elit.",
      image: 'https://ichef.bbci.co.uk/images/ic/1280xn/p08myjp0.jpg',
    },
  ],
};
export default Products;